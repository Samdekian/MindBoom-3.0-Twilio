
// This file now serves as a barrel export for the theme context hook
// We're standardizing on the ThemeContext implementation
import { useTheme } from '../contexts/ThemeContext';

export { useTheme };
