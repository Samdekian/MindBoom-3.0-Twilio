
import { Language } from "../types";

export const aboutTranslations = {
  "about": {
    "en": "About",
    "pt-BR": "Sobre"
  },
  "aboutUs": {
    "en": "About Us",
    "pt-BR": "Sobre Nós"
  }
};
