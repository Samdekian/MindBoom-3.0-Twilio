
// Basic WebRTC config hook for compatibility
export const useWebRTCConfig = () => {
  return {
    config: null,
    updateConfig: () => {}
  };
};
